/*
 * VerificaAspPosgrado.java
 *
 * Created on 7 de junio de 2007, 09:11 AM
 */

package nuevos;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.* ;
import BDatos.BaseDatos ;
import BDatos.BDadmisiones;
import configeci.configPosgrados;
import java.net.*;

/**
 *
 * @author Administrador
 */
public class VerificaAspPosgrado extends  HttpServlet{
    
    /** Creates a new instance of VerificaAsp */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException {
        response.setContentType("text/html;charset=UTF-8");
        configeci.configPosgrados confadmis = new configeci.configPosgrados();
        PrintWriter out = response.getWriter();
        HttpSession sesion;
        String documento, verdoc;
        BDadmisiones bd = new BDadmisiones();
        String ref = request.getParameter("ref");
        String idplan =request.getParameter("idplan");
        documento = request.getParameter("doc");
        int valor;
        String infpago = bd.VerificaPagoPos(ref, out) ;
        if (!infpago.equals("0.00"))
            valor = (new Integer(infpago)).intValue();
        else
            valor = 0 ;
        Vector  datos = bd.estadoInsc(ref, out) ;
        if (datos.size() > 0)
            response.sendRedirect("ImpresionPosgrado?documento="+documento+"&docest="+datos.elementAt(6)+"&ref="+ref+"&idplan="+idplan ) ;
        else{
            if ( valor >= 90000 )
                response.sendRedirect("FormularioPosgrado?doc="+documento+"&ref="+ref+"&idplan="+idplan);
            else
                response.sendRedirect("ErrorPagoPos") ;
        }
    }
}