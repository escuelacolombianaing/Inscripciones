/*
 * VerificaAspMaestria.java
 *
 * Created on 20 de mayo de 2008, 12:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package nuevos;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.* ;
import BDatos.BaseDatos ;
import BDatos.BDadmisiones;
import configeci.configmaestria;
import java.net.*;

/**
 *
 * @author lrodriguez
 */
public class VerificaAspMaestria extends  HttpServlet{
    
    /** Creates a new instance of VerificaAsp */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException {
        response.setContentType("text/html;charset=UTF-8");
        configeci.configmaestria confadmis = new configeci.configmaestria();
        PrintWriter out = response.getWriter();
        HttpSession sesion;
        String documento, verdoc;
        BDadmisiones bd = new BDadmisiones();
        String ref = request.getParameter("ref");
        documento = request.getParameter("doc");
        String idplan =  request.getParameter("idplan");
        int valor;
        String infpago = bd.VerificaPago(ref, out) ;
        if (!infpago.equals("0.00"))
            valor = (new Integer(infpago)).intValue();
        else  
            valor = 0 ;
        Vector  datos = bd.estadoInsc(ref, out) ;
        if (datos.size() > 0)
            response.sendRedirect("" +
                    "ImpresionMaestria?documento="+documento+"&docest="+datos.elementAt(6)+"&ref="+ref+"&idplan="+idplan ) ;
        else{
            if ( valor >= 90000 )
                response.sendRedirect("FormularioMaestria?doc="+documento+"&ref="+ref+"&idplan="+idplan);
            else
                response.sendRedirect("ErrorpagoMa?idplan="+idplan) ;
        }
    }
}