/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package otros;

import java.io.*;
import java.net.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author lrodriguez
 * @version
 */
public class Pregrados extends HttpServlet {

    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String host = "smtp.escuelaing.edu.co";
        String to = "pregrado@escuelaing.edu.co";
        String mensaje = new String("Su solicitud ha sido enviada exitosamente, pronto le estaremos contactando");
        HttpSession session = request.getSession(true);
        String Datos="";
        String programa = request.getParameter("programa");
        String nombre = request.getParameter("nombre"); 
        String grado=request.getParameter("grado");
        String fechagrad = request.getParameter("fechagrad");
        String colegio = request.getParameter("colegio");
        String ciudad = request.getParameter("ciudad");
        String telefono = request.getParameter("tel");
        String celular = request.getParameter("celular");
        String email = request.getParameter("email");
        String comentar = request.getParameter("comentarios");
        Datos= Datos + "Programa:" + programa + "\n" + "Nombres:" + nombre + "\n" + "Grado:" + grado + "\n" + "Fecha de Grado(dd/mm/aaaa):" + fechagrad + "\n"  +  "Colegio:" + colegio +  "\n" +   "Ciudad:" + ciudad + "\n" + "Telefono:" + telefono + "\n" + "Celular:" + celular + "\n" + "Comentarios:" +comentar + "\n" ;

         try{
            Properties prop = new Properties();
            prop.put("mail.smtp.host", host);
            Session ses1 = Session.getDefaultInstance(prop, null);
            MimeMessage msg = new MimeMessage(ses1);
            msg.setFrom(new InternetAddress(email));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            String asunto="Informaci�n Programas de Pregrado";
            String texto= Datos + "\n\n";
            msg.setSubject(asunto);
            msg.setText(texto);
            Transport.send(msg);
            } catch (Exception e) {
            mensaje = "<center>Por favor ingrese una direcci�n de correo v�lida en el campo email.</center>" ;
        }


        out.println("<html>");
        out.println("<head>");
        out.println("<title>Formulario Solicitud Informaci�n</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2> " + mensaje + "</h2>");
        out.println("</body>");
        out.println("</html>");
        out.close();
            }
    }