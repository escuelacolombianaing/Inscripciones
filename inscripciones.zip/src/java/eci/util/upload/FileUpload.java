/*
 * FileUpload.java
 *
 * Created on 5 de diciembre de 2006, 02:59 PM
 */
package eci.util.upload;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import com.oreilly.servlet.*;
import eci.adjuntar;
import BDatos.BDdocumentacion;

public class FileUpload extends javax.servlet.http.HttpServlet {

    protected boolean create() throws java.lang.Exception {

        return true;
    }

    public FileUpload() {   // Constructor.
    }

    private void unhandledEvent(String methodName, java.lang.Object event) {
    }

    /**
     * destroy Method
     */
    public void destroy() {
        super.destroy();
    // TODO: implement
    }

    /**
     * doGet Method
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //doPost(request,response);
    }

    /**
     * doPost Method
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String n = new String((String) request.getParameter("na"));
        String nombre = new String((String) request.getParameter("nombre"));
        String finalpath = new String((String) request.getParameter("fpath"));
        String spath = new String((String) request.getParameter("spath"));
        String doc = new String((String) request.getParameter("doc"));
        String carnet = new String((String) request.getParameter("carnet"));
        String estado = new String((String) request.getParameter("estado"));
        String nomestud = new String((String) request.getParameter("nomestud"));
        String tipocargue = new String((String) request.getParameter("tipocargue"));

        adjuntar a = new adjuntar(finalpath);
        a.rmArchivo(nombre);
        BDdocumentacion documentos = new BDdocumentacion();
        configeci.configuracion confEci = new configeci.configuracion();
        try {
            MultipartRequest multi = new MultipartRequest(request, finalpath, 25 * 1024 * 1024);
            File va = new File(finalpath + "/" + n);
            File na = new File(finalpath + "/" + nombre);
            boolean x = va.renameTo(na);
            Vector datos = documentos.Ducumensubidos(carnet, confEci.getPeriodo(), out);
            out.println("<p><b><center>" + nomestud + "<p>");

            if ((datos.size() <= 0) && estado.equals("-83") && tipocargue.equals("i")) {
                int respuesta = documentos.subedocuminsc(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() <= 0) && (estado.equals("-83") || estado.equals("-80")) && tipocargue.equals("f")) {
               int respuesta = documentos.subedocumliq(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() <= 0) && (estado.equals("-81")) && tipocargue.equals("t")) {
                int respuesta = documentos.subedocumtransfe(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() > 0) && estado.equals("-83") && tipocargue.equals("i")) {
                int respuesta = documentos.documinsc(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() > 0) && estado.equals("-83") || estado.equals("-80") && tipocargue.equals("f")) {
                int respuesta = documentos.documliq(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() > 0) && (estado.equals("-60")) && tipocargue.equals("m")) {
                int respuesta = documentos.docummat(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() > 0) && (estado.equals("-60") || estado.equals("-80")) && tipocargue.equals("f")) {
                int respuesta = documentos.documliq(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            } else if ((datos.size() > 0) && (estado.equals("-61") || estado.equals("-81")) && tipocargue.equals("t")) {
                int respuesta = documentos.documtransfe(carnet, confEci.getPeriodo(), out);
                response.sendRedirect("MensajeDocum?nomestud=" + nomestud);
            }

        } catch (Exception e) {
            response.sendRedirect("Documentacion?spath=" + spath + "&on=" + e.getMessage());

        }
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    // TODO: implement
    }
}