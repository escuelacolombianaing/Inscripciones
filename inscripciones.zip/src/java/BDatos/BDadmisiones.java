/*
 * BDadmisiones.java
 *
 * Created on 15 de marzo de 2007, 10:02 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package BDatos;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import BDatos.BaseDatos;

/**
 * /**F
 *
 * @author Administrador
 */
public class BDadmisiones extends BaseDatos {

    private String mensaje;

    /** Creates a new instance of BDadmisiones */
    public BDadmisiones() {
    }

    public Vector ExisteRef(String doc, String per, String prog) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select idinsc, nom, dpto from registro.pginscrip " +
                "where doc = '" + doc + "' and per = '" + per + "' ");

        try {
            conectarBD();
            retorno = consultar(consulta, 3, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para verificar si el estudiante al solicitar nro de refer esta en estado -12 autorizado a seguimiento
    //Esto debido a que muchos que no estan autorizados pagan la prenscripci�n.
    public Vector VerificaSeg(String doc, PrintWriter out) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select doc_est, estado from registro.estudiante " +
                "where doc_est = '" + doc + "'  ");

        try {
            conectarBD();
            retorno = consultar(consulta, 2, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }
    //consultar el ultimo plan de estudios de un programa

    public Vector VerificaPlan(String dpto) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String(" select registro.plan_estud.id_plan from registro.programas, registro.plan_estud " +
                " where (registro.programas.id_prog = registro.plan_estud.id_prog) and id_dpto = '" + dpto + "' and pmmat is not null and act = 'S'  ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public String VerificaPago(String numRef, PrintWriter out) {
        configeci.configuracion confeci = new configeci.configuracion();
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select convert(varchar(10),convert(int, vrpag)) from registro.pginscrip " +
                "where idinsc = " + numRef + " and per ='" + confeci.getPeriodo() + "' ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        if (retorno.size() > 0) {
            return retorno.elementAt(0).toString();
        } else {
            return "0.00";
        }
    }

    public String VerificaPagoPos(String numRef, PrintWriter out) {
        configeci.configPosgrados confeci = new configeci.configPosgrados();
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select convert(varchar(10),convert(int, vrpag)) from registro.pginscrip " +
                "where idinsc = " + numRef + " and per ='" + confeci.getPeriodo() + "' ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        if (retorno.size() > 0) {
            return retorno.elementAt(0).toString();
        } else {
            return "0.00";
        }
    }

    public String sigSecuencia(String entidad) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String("select convert(varchar(10), sig_sec) from registro.secuencias where nombre = '" + entidad + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
            consulta = new String("update registro.secuencias set sig_sec = sig_sec + incr where nombre = '" + entidad + "' ");
            retsec = actualizar(consulta);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        /*consulta = new String("update registro.secuencias set sig_sec = sig_sec + incr where nombre = '" + entidad + "' ") ;
        try {
        conectarBD();
        retsec = actualizar(consulta);
        } catch (Exception ex) {
        retsec = 0;
        mensaje= new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }*/
        desconectarBD();
        //if(retorno.size()>0)
        return retorno.elementAt(0).toString();
    /*else
    return mensaje;*/
    }

    public Vector estadoInsc(String numRef, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String("select id_est, num_sol, estado, nom_est, id_dpto, nro_snp, doc_est, tip_est, id_plan, nom_acud from registro.estudiante " +
                "where refins =  '" + numRef + "' ");

        try {
            conectarBD();
            retorno = consultar(consulta, 10, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para la generaci�n del formulario impreso inscritos a becas
    public Vector ConsultaInscritoBecas(String docEst, PrintWriter out) {
        configeci.configuracion confeci = new configeci.configuracion();
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select  registro.estudiante.id_est, doc_est, nom_est,id_dpto, nro_snp, lug_nac,registro.ciudades.nom_ciu, convert(varchar(10), fec_nac, 103), nro_libr, " +
                " nro_distr, dir_corr, tel_corr, emails, id_col, convert(varchar(10), fec_grado, 103),  avaluo_com, patrimonio, nom_acud, " +
                " docacu, dir_acud, tel_acud, nom_otr, dir_otr, tel_otr, nom_res, dir_res,tel_res, for_fin, vive_act, " +
                " pago_col,tip_viv,avaluo_com,patrimonio,par_acud,nom_acud, dir_acud,tel_acud, nom_otr,dir_otr, tel_otr, estrato,  ingreso, " +
                " ren_liq, vive_res, tip_est,nom_uni, num_sol, edu_res, id_pro, tip_res, pago_univ, ulttel, ultdir,registro.estudiante.celular, registro.responsable.celular, padre_egre,ciud.nom_ciu, id_ocu, anti_acti,email, interes_acad  " +
                " from registro.registro.estudiante, registro.ciudades, registro.responsable,registro.ciudades ciud    " +
                " where doc_est = '" + docEst + "' and  per_ing ='" + confeci.getPeriodo() + "' and " +
                "registro.ciudades.id_ciu= registro.estudiante.ciu_corr and registro.estudiante.id_est=registro.responsable.id_est and " +
                "ciud.id_ciu= registro.estudiante.lug_nac and tip_est='S' ");
        //   out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 61, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //PARA LA VALIDACION DE LAS ENTREVISTAS POSTULADOS A BECA JULIO GARAVITO - TRANSFERENCIAS
    public Vector ConsultaEntrev(String docEst, String per, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select registro.estudiante.nom_est, doc_est, tip_est,per_ing, fac_cor, estado,registro.estudiante.id_dpto " +
                " from registro.registro.estudiante " +
                " where doc_est = '" + docEst + "' and registro.estudiante.per_ing= '" + per + "' order by fac_cor ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 7, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector Diagnostico(String docEst, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select min (id_examen), registro.diagnostico.id_estud, lugar, fecha,  nom_est, id_dpto, hora,matematicas " +
                " from registro.registro.diagnostico, registro.estudiante " +
                " where registro.diagnostico.id_estud=registro.estudiante.id_est and registro.estudiante.doc_est='" + docEst + "'  " +
                " group by registro.diagnostico.id_estud, lugar, fecha,  nom_est, id_dpto, hora,matematicas ");

        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 8, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consultar n�mero de referencia
    public Vector Referencia(String docEst, String per, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select idinsc, nom from registro.pginscrip " +
                " where registro.pginscrip.doc='" + docEst + "' and per= '" + per + "' and tip in ('N', 'S', 'P') ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para la generaci�n del formulario impreso
    public Vector ConsultaInscrito(String docEst, String numRef, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select  registro.estudiante.id_est, doc_est, nom_est,id_dpto, nro_snp, lug_nac,registro.ciudades.nom_ciu, convert(varchar(10), fec_nac, 103), nro_libr, " +
                " nro_distr, dir_corr, tel_corr, emails, id_col, convert(varchar(10), fec_grado, 103),  avaluo_com, patrimonio, nom_acud, " +
                " docacu, dir_acud, tel_acud, nom_otr, dir_otr, tel_otr, nom_res, dir_res,tel_res, for_fin, vive_act, " +
                " pago_col,tip_viv,avaluo_com,patrimonio,par_acud,nom_acud, dir_acud,tel_acud, nom_otr,dir_otr, tel_otr, estrato,  ingreso, " +
                " ren_liq, vive_res, tip_est,nom_uni, num_sol, edu_res, id_pro, tip_res, pago_univ, ulttel, ultdir,registro.estudiante.celular, registro.responsable.celular, padre_egre,ciud.nom_ciu, id_ocu, anti_acti,email " +
                " from registro.registro.estudiante, registro.ciudades, registro.responsable,registro.ciudades ciud    " +
                " where doc_est = '" + docEst + "' and registro.estudiante.refins= '" + numRef + "' and " +
                "registro.ciudades.id_ciu= registro.estudiante.ciu_corr and registro.estudiante.id_est=registro.responsable.id_est and " +
                "ciud.id_ciu= registro.estudiante.lug_nac  ");
//out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 60, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector ConsultaHermanos(String docEst, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select nom_her, simultaneo,docher " +
                " from registro.hermanos, registro.estudiante " +
                " where doc_est= '" + docEst + "' and registro.estudiante.id_est=registro.hermanos.id_est  ");
        try {
            conectarBD();
            retorno = consultar(consulta, 3, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getCiudades() {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select idc, nomc from registro.lisciudad order by nomc");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Rangos para valor de matr�culas
    public Vector getRangomatric(String valor) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select vlr, vini,vfin from registro.rangomatric where vlr = '" + valor + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 3, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getCiudadcor() {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select id_ciu, nom_ciu from registro.ciudades" +
                "where registro.ciudades.id_ciu= registro.estudiante.ciu_corr ");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getProfesiones() {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select id_pro, nom_pro from registro.profesiones where cd_pro <> 'X' order by nom_pro");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getInscrito(String doc, String ref) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select idinsc, dpto, nom, doc, snp, ema, tip, ape1, ape2, nomest, tel_cel from registro.pginscrip " +
                "where doc = '" + doc + "' and idinsc = " + ref);
        try {
            conectarBD();
            retorno = consultar(consulta, 11, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getInfoEst(String idEst) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String(" select id_est, nom_est, tip_doc, doc_est, dir_corr, ciu_corr, tel_corr, " +
                " id_dpto, lug_exp, nom_acud, dir_acud, tel_acud, nom_otr, dir_otr, tel_otr, estado, dtur, clanum, " +
                " tip_est, valren, sem_est, par_acud, bas_pru, emails, sem_est, tip_viv, avaluo_com, estrato, " +
                "patrimonio, num_sol,convert(varchar, getdate(), 103),passwd, per_ing " +
                " from registro.registro.estudiante " +
                " where doc_est= '" + idEst + "'  ");
        if (idEst.length() <= 7) {
            consulta = consulta + "or id_est = '" + idEst + "' ";
        }
        try {
            conectarBD();
            retorno = consultar(consulta, 33, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para diferenciar los estudiantes que �nicamente hicieron un periodo acad�mico y ahora van a solicitar REINTEGRO
    //ya que la resta para ellos sera diferente a los q han hecho varios periodos acad�micos
    //contar en biblia_def cuantos periodos distintos tiene el estudiante.
    public String ReintegroPrimerS(String idEst, PrintWriter out) {

        Vector retorno = new Vector();
        String consulta = new String();
        /* consulta = new String(" select  count (distinct per_acad) from  registro.biblia_def " +
        " where clave='R' and id_est='" + idEst + "' ");
         */
        consulta = new String(" select  count (distinct per_acad) from  registro.biblia_def " +
                " where clave in ('R','Z') and id_est='" + idEst + "' ");

        //  out.println(consulta);

        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno.elementAt(0).toString();
    }

    public int getExiste(String idEst, String per) {
        int existe = -1;
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String(" select id_est " +
                " from registro.registro.estudiante " +
                " where doc_est= '" + idEst + "' and per_ing = '" + per + "' and tip_est <> 'S' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
            existe = Integer.parseInt(retorno.toString());
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno.size();
    }

    public String claveNum(String idEst) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select passwd from registro.estudiante " +
                " where id_est =  " + idEst + " ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno.elementAt(0).toString();
    }

    public String getNomCiudad(String ciudad) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select nom_ciu " +
                " from registro.registro.ciudades " +
                " where id_ciu = " + ciudad + "  ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        if (retorno.size() > 0) {
            return retorno.elementAt(0).toString();
        } else {
            return "";
        }
    }

    public Vector getPadres(String carnet) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select tip_res, nom_res, dir_res, tel_res, dir_acti, lug_res, tel_acti, " +
                "ciu_tra, carg_res, edu_res, vive_res, id_res, ren_liq, ingreso " +
                " from registro.registro.responsable " +
                " where id_est = '" + carnet + "'   order by id_res ");
        try {
            conectarBD();
            retorno = consultar(consulta, 14, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getSecuencia() {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select sig_sec  " +
                " from registro.secuencias" +
                " where registro.secuencias.nombre='NUM_SOLREINT' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector Documentacion(String docEst, String periodo, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = ("select nom_est,estado, blq_doc " +
                "from registro.estudiante where doc_est= '" + docEst + "' and per_ing= '" + periodo + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 3, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;

    }

    /*  public Vector Admitidos(String docEst, String periodo, PrintWriter out) {
    String consulta = new String();
    Vector retorno = new Vector();*/
    /*consulta = new String(" select  nom_est, id_dpto, estado, doc_est, nom_acudiente, nro_snp,ar_mat, ar_soc,ar_cie,ar_len,id_est,ar_ele,num_sol, tip_est, nivelicfes  " +
    " from registro.registro.estudiante " +
    " where doc_est = '" + docEst + "' and per_ing= '" + periodo + "' and tip_est = 'N'  ");
    //out.println(consulta);*/
    /*  consulta = new String(" select  nom_est, id_dpto, estado, doc_est, nom_acudiente, nro_snp,ar_mat, ar_soc,ar_cie,ar_len,id_est,ar_ele,num_sol, tip_est, nivelicfes, blq_doc, num_sol, convert(varchar(10),fec_insc, 103)  " +
    " from registro.registro.estudiante " +
    " where doc_est = '" + docEst + "' and tip_est in ('N','E','Z')  ");

    try {
    conectarBD();
    retorno = consultar(consulta, 18, 1);
    } catch (Exception ex) {
    mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
    }
    desconectarBD();
    return retorno;
    }*/
    /*  public Vector AdmitidosN(String docEst, String periodo, PrintWriter out) {
    String consulta = new String();
    Vector retorno = new Vector();*/
    /*consulta = new String(" select  nom_est, id_dpto, estado, doc_est, nom_acudiente, nro_snp,ar_mat, ar_soc,ar_cie,ar_len,id_est,ar_ele,num_sol, tip_est, nivelicfes  " +
    " from registro.registro.estudiante " +
    " where doc_est = '" + docEst + "' and per_ing= '" + periodo + "' and tip_est = 'N'  ");
    //out.println(consulta);*/
    /* consulta = new String(" select  nom_est, id_dpto, estado, doc_est, nom_acudiente, nro_snp,ar_mat, ar_soc,ar_cie,ar_len,id_est,ar_ele,num_sol, tip_est, nivelicfes, blq_doc, num_sol  " +
    " from registro.registro.estudiante " +
    " where doc_est = '" + docEst + "' and tip_est in ('N','E','Z')  ");

    try {
    conectarBD();
    retorno = consultar(consulta, 17, 0);
    } catch (Exception ex) {
    mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
    }
    desconectarBD();
    return retorno;
    }*/
    public Vector Niveles(String idprog, String periodo, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select  ma,fi,le,qui, as1,as2, as3,as4,as5,as6,as7,as8,as9,as10, as11,as12   " +
                " from registro.baspreinsnuevos " +
                " where prg= '" + idprog + "' and ping= '" + periodo + "' order by ma,fi,le  ");
        //out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 16, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector nomasignaturas(String cod1, String cod2, String cod3, String cod4, String cod5, String cod6, String cod7, String cod8, String cod9, String cod10, String cod11, String cod12, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select nom_asig   " +
                " from registro.asignatura " +
                " where cod_asig= '" + cod1 + "' or cod_asig= '" + cod2 + "' or cod_asig= '" + cod3 + "' or  cod_asig= '" + cod4 + "' or  cod_asig= '" + cod5 + "' " +
                " or cod_asig= '" + cod6 + "' or cod_asig= '" + cod7 + "' or cod_asig= '" + cod8 + "'  or cod_asig= '" + cod9 + "' or cod_asig= '" + cod10 + "' or cod_asig= '" + cod11 + "' or cod_asig= '" + cod12 + "' order by cod_asig");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }


    // Consulta para generar los admitidos proceso de readmisi�n-becas y reintegros
    // esperar si Nancy decide colocar fac_cor de admitidos en 1 para la consulta
   /* public Vector AdmitidosPregrado1(String doc, PrintWriter out) {
    String consulta = new String();
    Vector retorno = new Vector();
    consulta = new String("select nom_est, registro.estudiante.id_dpto,  estado, fac_cor, tip_est, doc_est,id_est, num_sol, nom_acudiente , ar_mat, ar_soc,ar_cie,ar_len,ar_ele, convert(varchar(10),fsolread, 103) " +
    " from registro.estudiante " +
    " where doc_est = '" + doc + "'  ");
    // out.println(consulta);
    //and estado in (-13, -19)
    try {
    conectarBD();
    retorno = consultar(consulta, 15, 1);
    } catch (Exception ex) {
    mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
    }
    desconectarBD();
    return retorno;
    }
     */
    public Vector AdmitidosPregrado(String doc, PrintWriter out, String periodo) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select nom_est,id_dpto, estado,doc_est,nom_acudiente,nro_snp, ar_mat, ar_soc,ar_cie,ar_len,ar_ele,  " +
                "id_est,num_sol,tip_est,nivelicfes,blq_doc,fac_cor, convert(varchar(10),fec_insc, 103),  convert(varchar(10),fsolread, 103), doc_liq, c_beca, per_ing, per_ingreal  " +
                " from registro.estudiante " +
                " where doc_est = '" + doc + "'  ");
        //and registro.estudiante.per_ing= '" + periodo + "'
        //out.println(consulta);
        //and estado in (-13, -19)
        try {
            conectarBD();
            retorno = consultar(consulta, 23, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para verificar si el estudiante becado tiene la anotacion correspondiente en la tabla anot_cad
    public Vector AnotacionBeca(String idest, String periodo, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select id_est, tip_anot,  per_acad, id_tex,tex_ano " +
                " from registro.anot_acad, registro.text_ano " +
                " where id_est = '" + idest + "' and tip_anot = id_tex  and registro.anot_acad.per_acad = '" + periodo + "'  ");

        try {
            conectarBD();
            retorno = consultar(consulta, 5, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector AnotacionReint(String idest, String periodo) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select id_tabla, tip_anot,  per " +
                " from registro.anotacion_aux " +
                " where id_tabla = '" + idest + "' and tip_anot = 1480  and registro.anotacion_aux.per = '" + periodo + "'  ");

        try {
            conectarBD();
            retorno = consultar(consulta, 3, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public int logconsultaadmitidos(String doc, String estado, PrintWriter out) {
        String consulta = new String("insert into registro.logconsultaadmitidos " +
                " (id_est,  estado, fecha) " +
                " values ( " + doc + ", " + estado + ", getdate() ) ");
        return this.actualiza(consulta);
    }

    //Guardar datos del contactenos de pregrado
    public int contactenos(String programa, String nombres, String grado, String fechagrad, String colegio, String ciudad, String tel, String celular, String email, String comentarios, PrintWriter out) {
        String consulta = new String("insert into registro.contactepregrado " +
                " values ( '" + programa.toUpperCase() + "', '" + nombres.toUpperCase() + "', " + grado + ", '" + fechagrad + "','" + colegio.toUpperCase() + "','" + ciudad.toUpperCase() + "','" + tel + "','" + celular + "', '" + email.toUpperCase() + "', '" + comentarios.toUpperCase() + "', getdate() ) ");
        return this.actualiza(consulta);
    }


    //Guarda inf basica del estudiante que solicito reclasificaci�n por la web
    public int logreclasifica(String doc, String niveles, PrintWriter out) {
        String consulta = new String("insert into registro.logreclasifica " +
                " (id_est, fecha, nvaclasifica) " +
                " values ( '" + doc + "', getdate(),  '" + niveles + "' ) ");
        //   out.println(consulta);
        return this.actualiza(consulta);
    }


    //insertar evento Gestion de Inf
    public int Gestion(String doc, String nombres, String apellido1, String apellido2, String mail, String telefono, String empresa, PrintWriter out) {
        String consulta = new String("insert into registro.inscrito_eventos " +
                " (id_evento, documento, nombres, apellido1, apellido2,mail, telefono,empresa) " +
                " values ( '21', '" + doc + "',  '" + nombres + "', '" + apellido1 + "', '" + apellido2 + "', '" + mail + "','" + telefono + "', '" + empresa + "' ) ");
        return this.actualiza(consulta);
    }

     //validar si ya esta inscrito a el evento

    public Vector ValidaGestion(String doc) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select  documento " +
                " from registro.inscrito_eventos" +
                " where id_evento = '21' and documento= '" + doc + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }


    //validar si hay cupos para el evento

    public Vector CuposGestion() {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select  count(*) " +
                " from registro.inscrito_eventos" +
                " where id_evento = '21' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public int clasificacion(String idEst, String niveles, PrintWriter out) {
        String consulta = new String("update registro.estudiante" +
                " set nivelicfes ='" + niveles + "'  " +
                " where id_est = '" + idEst + "' ");
        return this.actualiza(consulta);
    }

    //actualizar el fac_cor a 0 cuando el estudiante se postula a beca Julio G. A.
    public int becas(String idEst, PrintWriter out) {
        String consulta = new String("update registro.estudiante" +
                " set fac_cor ='0'  " +
                " where id_est = '" + idEst + "' ");
        return this.actualiza(consulta);
    }

    //Consulta para mostrar el cod_plan en la rta de admitido
    public Vector Planestud(String docEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();

        consulta = new String(" select  REGISTRO.ESTUDIANTE.ID_PLAN, COD_PLAN  " +
                " from REGISTRO.ESTUDIANTE, REGISTRO.PLAN_ESTUD " +
                " where doc_est = '" + docEst + "' and  REGISTRO.ESTUDIANTE.ID_PLAN=REGISTRO.PLAN_ESTUD.ID_PLAN");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 0);
        } catch (Exception ex) {

            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para mostrar los puntajes de corte para el periodo en que presento el icfes
    public Vector baseicfes(String pericfes, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select  per, matpb,matpa, lenpb,lenpa,filpb,filpa,fispb,fispa, quipb,quipa " +
                " from registro.registro.baseicfes " +
                " where per= '" + pericfes + "'  ");
        //   out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 11, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //admitidos posgrado
    public Vector AdmitidosPos(String docEst, String plan, String periodo, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select  id_est, nom_est, id_plan, estado, doc, semnv " +
                " from registro.registro.estudiante " +
                " where doc_est = '" + docEst + "' and id_plan = " + plan + " and tip_est = 'P' and per_ing = '" + periodo + "' ");
        //out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 6, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public String getProfesion(String idprof) {
        Vector retorno = new Vector();
        String consulta = new String();
        consulta = new String("select nom_pro from registro.profesiones where id_pro = " + idprof);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        if (retorno.size() > 0) {
            return retorno.elementAt(0).toString();
        } else {
            return "";
        }
    }

    //Consultas para la generaci�n del formulario impreso POSGRADO: datos personales,educaci�n, referencias y distinciones
    public Vector ConsultaInscritoPos(String docEst, String numRef, String periodo, PrintWriter out) {
        Vector retorno = new Vector();
        String consulta = new String();

        consulta = new String(" select nom_est,doc_est,id_plan,lug_nac, convert(varchar(10), fec_nac, 103),dir_corr,ciu_corr,tel_corr,dir_otr," +
                "tel_otr,emails,ulttel,univ,prog,titu,pais,desde,hasta, for_fin, num_sol, " +
                "nom_acud,tel_acud, tpgrp, obsv_act, nom_ciu, tpgrp " +
                "from registro.estudiante,registro.estudios_ant,  registro.ciudades " +
                "where registro.estudiante.id_est= registro.estudios_ant.id_est and  " +
                "registro.estudiante.doc_est= '" + docEst + "' and registro.estudiante.refins= '" + numRef + "' and registro.ciudades.id_ciu= registro.estudiante.lug_nac and per_ing = '" + periodo + "'  ");

        try {
            conectarBD();
            retorno = consultar(consulta, 26, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector ExperienciaPos(String docEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select entidad,cargo,exper,jefinm, teljef " +
                " from registro.experiencia, registro.estudiante " +
                " where doc_est= '" + docEst + "' and registro.estudiante.id_est=registro.experiencia.id_est and per_ing='" +
                MaximoperPos(docEst, out) + "' ");

        try {
            conectarBD();
            retorno = consultar(consulta, 5, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public String MaximoperPos(String docEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();

        consulta = new String(" select max(per_ing)  " +
                " from  registro.estudiante " +
                " where doc_est= '" + docEst + "'  ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno.elementAt(0).toString();
    }

    public Vector ReferenciasPos(String docEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select nomr,entid,carr,telef  " +
                " from registro.referpos, registro.estudiante " +
                " where doc_est= '" + docEst + "' and registro.estudiante.id_est=registro.referpos.id_est and per_ing='" +
                MaximoperPos(docEst, out) + "'");
        // out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 4, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector DistincionPos(String docEst, PrintWriter out) {
        Vector retorno = new Vector();
        String consulta = new String();

        consulta = new String(" select distin, entidad, anio   " +
                " from registro.distinciones, registro.estudiante " +
                " where doc_est= '" + docEst + "' and registro.estudiante.id_est=registro.distinciones.id_est and per_ing='" +
                MaximoperPos(docEst, out) + "' ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 3, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //entrevistas para posgrados y maestria
    public Vector Entrevistas(String doc, String plan, PrintWriter out, String per) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select nom_est, registro.estudiante.id_plan, iddpto, convert(varchar, fec, 103), convert(varchar, fec, 108), idest, idprof, sitio, nom_prof, titu,estado " +
                " from registro.estudiante, registro.dispentrev, registro.profesor, registro.estudios_ant " +
                " where doc_est = '" + doc + "' and registro.estudiante.id_plan = '" + plan + "' and per_ing = '" + per + "' and registro.estudios_ant.tit='1' and registro.estudiante.id_est = registro.dispentrev.idest " +
                " and registro.profesor.id_prof = registro.dispentrev.idprof and registro.estudiante.id_est = registro.estudios_ant.id_est ");
        try {
            conectarBD();
            retorno = consultar(consulta, 11, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Entrevistas para pregrado readmisi�n
  /*  public Vector EntrevistasRead(String doc, String iddpto, PrintWriter out, String per){
    String consulta = new String();
    Vector retorno = new Vector();


    consulta=new String("select nom_est, registro.estudiante.id_dpto, convert(varchar, fec, 103), convert(varchar, fec, 108), idest, idprof, sitio, nom_prof, estado, fac_cor " +
    " from registro.estudiante, registro.dispentrev, registro.profesor "  +
    " where doc_est = '"+ doc +"' and registro.estudiante.id_dpto = '"+ iddpto +"' and per_ing = '"+ per +"' and registro.estudiante.id_est = registro.dispentrev.idest " +
    " and registro.profesor.id_prof = registro.dispentrev.idprof " );

    try {
    conectarBD();
    retorno = consultar(consulta, 10, 1);
    } catch (Exception ex) {
    mensaje= new String("Unable to fetch status due to SQLException: " + ex.getMessage());
    }
    desconectarBD();
    return retorno;
    }*/
    //Entrevistas para pregrado readmision, transferencias,Becas
    public Vector Entrevistas(String doc, PrintWriter out, String per) {
        String consulta = new String();
        Vector retorno = new Vector();

        consulta = new String("select nom_est, registro.estudiante.id_dpto, convert(varchar, fec, 106), substring(convert(varchar, fec, 108), 1,5), " +
                " idest, idprof, sitio, nom_prof, estado, fac_cor, convert(varchar, fec1, 106), substring(convert(varchar, fec1, 108),1,5),  tip_est, " +
                "(select nom_prof from registro.profesor where id_prof = idprof1) as nmprof1, sitio1 " +
                " from registro.estudiante, registro.dispentrev, registro.profesor " +
                " where doc_est = '" + doc + "'  " +
                " and registro.estudiante.id_est = registro.dispentrev.idest " +
                " and registro.profesor.id_prof = registro.dispentrev.idprof and registro.dispentrev.per = '" + per + "' ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 15, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para verificar fac_cor del estudiante q solicito la readmision, ya q en la tabla
    //dispentrev solo estaran los registros de quienes tengan entrevistas
    //fac_cor 1=Admitido no requiere entrevista, 0 Citado a entrevista.
    //esto se paso al contexto de estudiantes porque es pregrado
    public Vector EstadoReadmision(String docEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select nom_est, registro.estudiante.id_dpto,  estado, fac_cor, doc_est, tip_est, per_ing  " +
                " from registro.estudiante " +
                " where doc_est = '" + docEst + "'  and estado in (-13, -22,3,6,-23, -25, -19) and registro.estudiante.tip_est= 'Z ' order by fac_cor ");
        //out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 7, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Entrevistas readmisiones
    public Vector EntrevistasRead(String docEst, PrintWriter out) {
        Vector retorno = new Vector();
        int retsec = 0;
        String consulta = new String();
        consulta = new String(" select registro.estudiante.nom_est, doc_est, tip_est,per_ing, fac_cor, estado,registro.estudiante.id_dpto " +
                " from registro.registro.estudiante " +
                " where doc_est = '" + docEst + "' and registro.estudiante.tip_est= 'Z ' order by fac_cor ");
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 7, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector Titulo(String idEst) {
        String consulta = new String();
        Vector retorno = new Vector();

        consulta = new String(" select top 1 id_est, titu " +
                " from registro.registro.estudios_ant " +
                " where id_est = '" + idEst + "' and tit='1' ");

        try {
            conectarBD();
            retorno = consultar(consulta, 2, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector Becas(String doc, PrintWriter out, String per) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select nom_est, doc_est,id_dpto  " +
                " from registro.estudiante " +
                " where doc_est = '" + doc + "'  and per_ing = '" + per + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 3, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //Consulta para generar los tutores de los estudiantes de maestria
    public Vector Tutores(String doc, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();

        consulta = new String("select id_prof, nom_prof,doc_est, email  " +
                " from registro.profesor,registro.tutoreado,registro.estudiante " +
                " where id_prof=idprof and doc_est= '" + doc + "' and idest=id_est ");
        //out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 4, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector EntrevistasBecas(String doc) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select nom_est, registro.estudiante.id_dpto, convert(varchar, fec, 106), convert(varchar, fec, 108), " +
                " idest, idprof, sitio, nom_prof, estado, fac_cor, convert(varchar, fec1, 106), convert(varchar, fec1, 108), " +
                "(select nom_prof from registro.profesor where id_prof = idprof1) as nmprof1, sitio1 " +
                " from registro.estudiante, registro.dispentrev, registro.profesor " +
                " where doc_est = '" + doc + "' and registro.estudiante.tip_est = 'S' " +
                " and registro.estudiante.id_est = registro.dispentrev.idest " +
                " and registro.profesor.id_prof = registro.dispentrev.idprof ");
        //out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 14, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    //****************************************************
    //************* Solicitud de Readmisi�n *************
    public Vector getSolRead(String idEst) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select fsolread, tip_est from registro.estudiante " +
                " where id_est = '" + idEst + "' ");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector getValidaSolRead(String idEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String(" select id_est from registro.estudiante " +
                " where estado in (-22,3,6,-23) and doc_est = '" + idEst + "' and per_ing > '2009-2'");
        /*id_est in " +
        " (select id_est from registro.biblia_def " +
        " where per_acad > '2007' and per_acad not like '%-0' " +
        " group by id_est " +
        " having min(per_acad) = max(per_acad) and " +
        " min(per_acad) = '" + perant + "') " +
        " and estado = -22 and doc_est = '" + idEst + "' ");*/
        //  out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 1, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public int setSolRead(String idEst) {
        String consulta = new String();
        consulta = new String("update registro.estudiante " +
                " set fsolread = getdate (), tip_est = 'Z' " +
                " where id_est = '" + idEst + "' ");
        return this.actualizar(consulta);
    }


    /* public Vector pregrado( PrintWriter out, String per){
    String consulta = new String();
    Vector retorno = new Vector();
    consulta=new String("select per_actual, convert(varchar(10), fec_nuevos, 103), convert(varchar(10), fec_trans, 103), convert(varchar(10), fec_seg, 103),convert(varchar(10), fec_reint, 103) , convert(varchar(10), fec_becas, 103), convert(varchar(10), fec_readmi, 103),  " +
    "convert(varchar(10), entrev_readmi, 103),convert(varchar(10), entrev_trans, 103), convert(varchar(10), entrev_becas, 103), convert(varchar(10), admi_readmi, 103), convert(varchar(10),admi_becas, 103),convert(varchar(10),admi_reint, 103),papeles_nvos, " +
    "papeles_trans, papeles_seg, papeles_becas, per_ant" +
    " from registro.inspregrado "  +
    " where per_actual = '"+ per +"' " );
    //  out.println(consulta);
    try {
    conectarBD();
    retorno = consultar(consulta, 18, 0);
    } catch (Exception ex) {
    mensaje= new String("Unable to fetch status due to SQLException: " + ex.getMessage());
    }
    desconectarBD();
    return retorno;
    }*/
    public Vector pregrado(PrintWriter out, String per, String tipprog) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select per_actual, convert(varchar(10), fecha_inicio, 103),   " +
                "convert(varchar(10), fecha_fin, 103), tipo_est, ent_papeles , estado , resta_sol, fechahoraind  " +
                "from registro.inscrito_pregrado " +
                "where per_actual = '" + per + "' and tipo_est= '" + tipprog + "'");

        try {
            conectarBD();
            retorno = consultar(consulta, 8, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector Cronogramas(PrintWriter out, String per, String prog) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select estado, id_evento, per_acad, convert(varchar(10), fecinicio,103),  convert(varchar(10),fecfin,103),inscripprepa,cursosprepa, convert(varchar(10), citaentrev,103), entrev,  " +
                "examen,  convert(varchar(10), rtaadmi,103), rtaadminiv, ordenesniv, ordenesesp, pagosniv, pagosesp, induccion, firmaactaniv, " +
                "contniv, firmaactaesp, convert(varchar(10), clases,103), creditos, vlrcredito, vlrniv,vlrtotal, cohorte, preinscripcion, fecasigplan, horasalonclases, convert(varchar(10), ini_cronograma,103), convert(varchar(10), fin_cronograma,103)  " +
                "from registro.cronogramaspos " +
                "where  id_evento='" + prog + "'");
        // out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 31, 0);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

    public Vector encuentropadres(PrintWriter out, String idprog) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select id_programa,  fechasitio, grupo1,grupo2,grupo3, reclamar " +
                "from registro.reunepadres " +
                "where  id_programa= '" + idprog + "'");

        try {
            conectarBD();
            retorno = consultar(consulta, 6, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

//GENERAR NRO DE DOCUMENTOS PARA HACER INSERT EN REGISTRO.VERIFICA_DOCUM PARA EL CARGUE DE DOCUMENTOS
    public Vector Validadocum() {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select id_doc,  descripcion " +
                "from registro.docum_adm ");
        try {
            conectarBD();
            retorno = consultar(consulta, 2, 1);
        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }

//consultar datos del colegio segun el id del estudiante
    public Vector Colegio(String idEst, PrintWriter out) {
        String consulta = new String();
        Vector retorno = new Vector();
        consulta = new String("select registro.estudiante.id_col, nom_col, dpto, munip " +
                " from registro.colegios, registro.estudiante " +
                " where registro.colegios.id_col=registro.estudiante.id_col and id_est= '" + idEst + "' ");
        //   out.println(consulta);
        try {
            conectarBD();
            retorno = consultar(consulta, 4, 0);

        } catch (Exception ex) {
            mensaje = new String("Unable to fetch status due to SQLException: " + ex.getMessage());
        }
        desconectarBD();
        return retorno;
    }
}
