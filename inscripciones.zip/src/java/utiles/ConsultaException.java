/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utiles;

/**
 *
 * @author Juan Pablo Garcia
 */

public class ConsultaException extends Exception {

    public ConsultaException(String msg) {
        super(msg);
    }
}
